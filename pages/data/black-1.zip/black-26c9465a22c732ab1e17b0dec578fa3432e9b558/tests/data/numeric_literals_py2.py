#!/usr/bin/env python2.7

x = 123456789L
x = 123456789l
x = 123456789
x = 0xb1acc

# output


#!/usr/bin/env python2.7

x = 123456789L
x = 123456789L
x = 123456789
x = 0xB1ACC
