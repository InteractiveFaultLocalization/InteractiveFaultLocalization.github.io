*Black* exceptions
==================

*Contents are subject to change.*

.. currentmodule:: black

.. autoexception:: black.CannotSplit

.. autoexception:: black.FormatError

.. autoexception:: black.FormatOn

.. autoexception:: black.FormatOff

.. autoexception:: black.NothingChanged
