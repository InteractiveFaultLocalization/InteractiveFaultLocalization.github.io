#!/usr/bin/env python2
from __future__ import unicode_literals as _unicode_literals
from __future__ import absolute_import
from __future__ import print_function as lol, with_function

u'hello'
U"hello"
Ur"hello"

# output


#!/usr/bin/env python2
from __future__ import unicode_literals as _unicode_literals
from __future__ import absolute_import
from __future__ import print_function as lol, with_function

"hello"
"hello"
r"hello"
