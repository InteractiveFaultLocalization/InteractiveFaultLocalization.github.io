# fmt: off
@test([
    1, 2,
    3, 4,
])
# fmt: on
def f(): pass

@test([
    1, 2,
    3, 4,
])
def f(): pass

# output

# fmt: off
@test([
    1, 2,
    3, 4,
])
# fmt: on
def f():
    pass


@test(
    [1, 2, 3, 4,]
)
def f():
    pass
