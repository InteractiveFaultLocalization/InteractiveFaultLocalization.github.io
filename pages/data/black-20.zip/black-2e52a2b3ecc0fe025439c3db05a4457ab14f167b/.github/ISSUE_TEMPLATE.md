Howdy! Sorry you're having trouble. To expedite your experience,
provide some basics for me:

Operating system:
Python version:
Black version:
Does also happen on master:

To answer the last question, follow these steps:
* create a new virtualenv (make sure it's the same Python version);
* clone this repository;
* run `pip install -e .`;
* make sure it's sane by running `python setup.py test`; and
* run `black` like you did last time.
